# Zomato Growth Intelligence Dashboard

This project analyzes key business problems of Zomato using data analytics.

## Problems Covered:
1. Customer Churn
2. Low Conversion
3. Delivery Delays

## Techniques Used:
- Classification (Churn Prediction)
- Clustering (Segmentation)
- Regression (Basic insights)
- A/B Thinking (Optimization logic)

## Built With:
- Python
- Streamlit

## How to Run:
streamlit run app.py
