import streamlit as st
import pandas as pd
import numpy as np

st.title("Zomato Growth Intelligence Dashboard")

data = pd.read_csv("data.csv")

st.sidebar.title("Navigation")
option = st.sidebar.selectbox(
    "Select Problem",
    ["Churn Analysis", "Conversion Analysis", "Delivery Analysis"]
)

if option == "Churn Analysis":
    st.header("🔴 Customer Churn Analysis")
    data["churn"] = data["last_order_days"].apply(lambda x: 1 if x > 10 else 0)
    st.subheader("Churn Distribution")
    st.bar_chart(data["churn"].value_counts())
    st.subheader("High Risk Users")
    st.write(data[data["churn"] == 1])

elif option == "Conversion Analysis":
    st.header("🔵 Conversion & Segmentation")
    data["segment"] = data["order_count"].apply(
        lambda x: "Frequent" if x > 5 else "Occasional"
    )
    st.subheader("Customer Segments")
    st.bar_chart(data["segment"].value_counts())
    st.subheader("Segment Data")
    st.write(data[["user_id", "segment", "avg_order_value"]])

elif option == "Delivery Analysis":
    st.header("🟢 Demand & Delivery Insights")
    st.subheader("Orders by City")
    city_orders = data.groupby("city")["total_orders"].sum()
    st.bar_chart(city_orders)
    data["delay_risk"] = np.where(data["order_count"] < 3, "High", "Low")
    st.subheader("Delay Risk")
    st.write(data[["user_id", "city", "delay_risk"]])
